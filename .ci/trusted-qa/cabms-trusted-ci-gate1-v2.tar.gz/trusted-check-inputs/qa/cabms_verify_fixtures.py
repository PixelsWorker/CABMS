import hashlib
import json
import os
import sys

here = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(here, "cabms_fixture_hashes.json"), encoding="utf-8") as fh:
    expected = json.load(fh)["fixtures"]

for rel_path, exp_hash in expected.items():
    if not os.path.isfile(rel_path):
        print(f"MISSING fixture: {rel_path}", file=sys.stderr)
        sys.exit(1)
    with open(rel_path, "rb") as f:
        actual = hashlib.sha256(f.read()).hexdigest()
    if actual != exp_hash:
        print(f"HASH MISMATCH {rel_path}: expected {exp_hash}, got {actual}", file=sys.stderr)
        sys.exit(1)

print(f"Verified {len(expected)} approved historical fixture files.")
