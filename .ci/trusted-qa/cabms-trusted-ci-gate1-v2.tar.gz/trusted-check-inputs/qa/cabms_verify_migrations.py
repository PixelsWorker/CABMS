"""Verify approved migration bytes using the protected base inventory."""
import hashlib
import json
from pathlib import Path

manifest = json.loads(Path(__file__).with_name("cabms_migration_hashes.json").read_text(encoding="utf-8"))
if len(manifest) != 23:
    raise SystemExit("Expected the 23 approved migration entries.")
for filename, expected in manifest.items():
    file = Path("migrations") / filename
    if not file.is_file() or hashlib.sha256(file.read_bytes()).hexdigest() != expected:
        raise SystemExit("Missing or changed approved migration file " + filename)
print(f"Verified {len(manifest)} approved migration files.")
